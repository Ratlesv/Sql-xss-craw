# sql_and_xss_crawler
modify header.txt if u want to add cookie or extra headers
just run `python3 main.py -u <url> --header_file header.txt`
